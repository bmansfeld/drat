## ----setup, echo=FALSE, results="hide"-----------------------------------
knitr::opts_chunk$set(tidy=FALSE, cache=FALSE,
                      dev="png",
                      message=FALSE, error=FALSE, warning=TRUE)

## ----quickStart, eval=FALSE----------------------------------------------
#  
#  #load the package
#  library("QTLseqr")
#  
#  #Set sample and file names
#  HighBulk <- "SRR834931"
#  LowBulk <- "SRR834927"
#  file <- "SNPs_from_GATK.table"
#  
#  #Choose which chromosomes will be included in the analysis (i.e. exclude smaller contigs)
#  Chroms <- paste0(rep("Chr", 12), 1:12)
#  
#  #Import SNP data from file
#  df <-
#      importFromGATK(
#          file = file,
#          highBulk = HighBulk,
#          lowBulk = LowBulk,
#          chromList = Chroms
#       )
#  
#  #Filter SNPs based on some criteria
#  df_filt <-
#      filterSNPs(
#          SNPset = df,
#          refAlleleFreq = 0.20,
#          minTotalDepth = 100,
#          maxTotalDepth = 400,
#          minSampleDepth = 40,
#          minGQ = 99
#      )
#  
#  
#  #Run G' analysis
#  df_filt <- runGprimeAnalysis(
#      SNPset = df_filt,
#      windowSize = 1e6,
#      outlierFilter = "deltaSNP")
#  
#  #Plot
#  plotQTLStats(SNPset = df_filt, var = "deltaSNP", plotThreshold = TRUE, q = 0.01)
#  plotQTLStats(SNPset = df_filt, var = "Gprime", plotThreshold = TRUE, q = 0.01)
#  
#  #export summary CSV
#  getQTLTable(SNPset = df_filt, alpha = 0.01, export = TRUE, fileName = "my_BSA_QTL.csv")

## ----VCFrow, echo=FALSE, warning=FALSE-----------------------------------
library(kableExtra)
x <- data.frame(CHROM = "Chr1", POS = 31071, ID = ".", REF = "A", ALT = "G", QUAL = 1390.44, FILTER = "PASS", INFO = "..\\*...", FORMAT = "GT:AD:DP:GQ:PL", SRR834927 = "0/1:34,36:70:99:897,0,855", SRR834931 = "0/1:26,22:48:99:522,0,698")
kable_styling(knitr::kable(x = x, format = "latex", booktabs = TRUE), latex_options = "scale_down")

## ----install-------------------------------------------------------------
#Install step if you have not done so yet:
#devtools::install_github("bmansfeld/QTLseqr")
library("QTLseqr")

## ----installdata---------------------------------------------------------
#download and load data package (~50Mb)
devtools::install_github("bmansfeld/Yang2013data")
library("Yang2013data")

#Import the data
rawData <- system.file(
    "extdata", 
    "Yang_et_al_2013.table", 
    package = "Yang2013data", 
    mustWork = TRUE)

## ---- eval = FALSE-------------------------------------------------------
#  rawData <- "C:/PATH/TO/MY/DIR/My_BSA_data.table"

## ------------------------------------------------------------------------
HighBulk <- "SRR834931"
LowBulk <- "SRR834927"
Chroms <- paste0(rep("Chr", 12), 1:12)

## ----import, cache=TRUE--------------------------------------------------
#import data
df <-
    importFromGATK(
        file = rawData,
        highBulk = HighBulk,
        lowBulk = LowBulk,
        chromList = Chroms
     )

## ----viewdf--------------------------------------------------------------
head(df)

## ----plothist1, warning = FALSE, fig.align="center", fig.width=4, fig.height=4, dpi=300----
library("ggplot2")
ggplot(data = df) + 
    geom_histogram(aes(x = DP.HIGH + DP.LOW)) + 
    xlim(0,1000)


## ----plothist2, warning=FALSE, fig.align = "center", fig.width=4, fig.height=4, dpi=300----
ggplot(data = df) +
    geom_histogram(aes(x = REF_FRQ))

## ----filtSNPs-source, eval = FALSE, message = FALSE----------------------
#  df_filt <-
#      filterSNPs(
#          SNPset = df,
#          refAlleleFreq = 0.20,
#          minTotalDepth = 100,
#          maxTotalDepth = 400,
#          minSampleDepth = 40,
#          minGQ = 99,
#          verbose = TRUE
#      )

## ----filtSNPs-msgs, message = TRUE, warning = FALSE, collapse = TRUE, echo = FALSE----
df_filt <-
    filterSNPs(
        SNPset = df,
        refAlleleFreq = 0.20,
        minTotalDepth = 100,
        maxTotalDepth = 400,
        minSampleDepth = 40,
        minGQ = 99,
        verbose = TRUE
    )

## ----gprimeanalysis-src, eval = FALSE------------------------------------
#  df_filt <- runGprimeAnalysis(df_filt,
#      windowSize = 1e6,
#      outlierFilter = "deltaSNP",
#      filterThreshold = 0.1)

## ----gprimeanalysis-msg, message = TRUE, warning = FALSE, collapse = TRUE, echo = FALSE----
df_filt <- runGprimeAnalysis(df_filt,
    windowSize = 1e6,
    outlierFilter = "deltaSNP",
    filterThreshold = 0.1)

## ------------------------------------------------------------------------
head(df_filt)

## ----gprimedist hampel, message = FALSE, warning = FALSE, fig.height=4 , dpi=300----
plotGprimeDist(SNPset = df_filt, outlierFilter = "Hampel")


## ----gprimedist deltaSNP, message=FALSE, warning = FALSE, fig.height=4, dpi=300----
plotGprimeDist(SNPset =df_filt, outlierFilter = "deltaSNP", filterThreshold = 0.1)

## ----plotnSNPs, fig.align = "center", fig.width=12, fig.height=4---------
p1 <- plotQTLStats(SNPset = df_filt, var = "nSNPs")
p1

## ----plotdeltaSNP, fig.align = "center", fig.width=12, fig.height=4, , dpi=300----
p2 <- plotQTLStats(SNPset = df_filt, var = "deltaSNP")
p2

## ----plotGprime, fig.align = "center", fig.width=12, fig.height=4, , dpi=300----
p3 <- plotQTLStats(SNPset = df_filt, var = "Gprime", plotThreshold = TRUE, q = 0.01)
p3

## ----subsetlogpval, , fig.align = "center", fig.width=6, fig.height=3, , dpi=300----
QTLplots <- plotQTLStats(
    SNPset = df_filt, 
    var = "negLog10Pval", 
    plotThreshold = TRUE, 
    q = 0.01, 
    subset = c("Chr1", "Chr8")
    )
QTLplots

## ----getsigreg-----------------------------------------------------------
QTL <- getSigRegions(SNPset = df_filt, alpha = 0.01)
head(QTL[[1]])

## ----QTLtable------------------------------------------------------------
results <- getQTLTable(SNPset = df_filt, alpha = 0.01, export = FALSE)
results

