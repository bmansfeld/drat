# ############### NEW FUNCTIONS ################
# ## pipe: https://stackoverflow.com/questions/27947344/r-use-magrittr-pipe-operator-in-self-written-package
# 
# getG <- function(LowRef, HighRef, LowAlt, HighAlt)
# {
#     exp <- c(
#         (LowRef+HighRef)*(LowRef+LowAlt)/(LowRef + HighRef + LowAlt + HighAlt),
#         (LowRef+HighRef)*(HighRef+HighAlt)/(LowRef + HighRef + LowAlt + HighAlt),
#         (LowRef+LowAlt)*(LowAlt+HighAlt)/(LowRef + HighRef + LowAlt + HighAlt),
#         (LowAlt+HighAlt)*(HighRef+HighAlt)/(LowRef + HighRef + LowAlt + HighAlt)
#     )
#     obs <- c(LowRef, HighRef, LowAlt, HighAlt)
#     
#     G <- 2 * (rowSums(obs * log(matrix(obs, ncol = 4) / matrix(exp, ncol = 4))))
#     return(G)
# }
# 
# tricubeGStat <- function(POS, GStat, windowSize = 2e6)
# {
#     stats::predict(locfit::locfit(GStat ~ locfit::lp(POS, h = windowSize, deg = 0)), POS)
# }
# 
# 
# getPvals <- function(deltaSNP, Gprime, outlierFilter = c("deltaSNP", "Hampel"))
# {
#     if(outlierFilter == "deltaSNP") {
#         trimGprime <- Gprime[abs(deltaSNP) < 0.1]
#     } else {
#         lnGprime <- log(Gprime)
#         
#         medianLogGprime <- median(lnGprime)
#         
#         # calculate left median absolute deviation for the trimmed G' prime set
#         MAD <- median(medianLogGprime - lnGprime[lnGprime <= medianLogGprime])
#         
#         # Trim the G prime set to exclude outlier regions (i.e. QTL) using Hampel's rule
#         trimGprime <-
#             Gprime[lnGprime - median(lnGprime) <= 5.2 * MAD]
#     }
#     
#     medianTrimGprime <- median(trimGprime)
#     
#     # estimate the mode of the trimmed G' prime set using the half-sample method
#     modeTrimGprime <-
#         modeest::mlv(x = trimGprime, bw = 0.5, method = "hsm")$M
#     
#     muE <- log(medianTrimGprime)
#     varE <- abs(muE - log(modeTrimGprime))
#     #use the log normal distribution to get pvals
#     pval <-
#         1 - plnorm(q = Gprime,
#             meanlog = muE,
#             sdlog = sqrt(varE))
#     
#     return(pval)
# }
# 
# 
# # getPvals <- function(Gprime)
# # {
# #     lnGprime <- log(Gprime)
# #     
# #     medianLogGprime <- median(lnGprime)
# #     
# #     # calculate left median absolute deviation for the trimmed G' prime set
# #     MAD <- median(medianLogGprime - lnGprime[lnGprime <= medianLogGprime])
# #     
# #     # Trim the G prime set to exclude outlier regions (i.e. QTL) using Hampel's rule
# #     trimGprime <-
# #         Gprime[lnGprime - median(lnGprime) <= 5.2 * MAD]
# #     
# #     medianTrimGprime <- median(trimGprime)
# #     
# #     # estimate the mode of the trimmed G' prime set using the half-sample method
# #     modeTrimGprime <-
# #         modeest::mlv(x = trimGprime, bw = 0.5, method = "hsm")$M
# #     
# #     muE <- log(medianTrimGprime)
# #     varE <- abs(muE - log(modeTrimGprime))
# #     
# #     #use the log normal distribution to get pvals
# #     pval <-
# #         1 - plnorm(q = Gprime,
# #             meanlog = muE,
# #             sdlog = sqrt(varE))
# #     return(pval)
# # }
# 
# getFDRThreshold <- function(SNPset, alpha = 0.01)
# {
#     pVals <- SNPset$pvalue
#     pVals <- sort(pVals,decreasing = FALSE)
#     pAdj <- p.adjust(pVals, method = "BH")
#     fdrThreshold <- pVals[max(which(pAdj < alpha))]
#     return(fdrThreshold)
# }
# # 
# # runGprimeAnalysis <- function(SNPset, windowSize = 1e6, outlierFilter = "deltaSNP")
# # {
# #     SNPset <- SNPset %>%
# #         group_by(CHROM) %>%
# #         mutate(
# #             G = getG(
# #                 LowRef = AD_REF.LOW,
# #                 HighRef = AD_REF.HIGH,
# #                 LowAlt = AD_ALT.LOW,
# #                 HighAlt = AD_ALT.HIGH
# #             ),
# #             Gprime = tricubeGStat(POS, G, windowSize)
# #             ) %>%
# #         ungroup() %>%
# #            mutate(
# #                pvalue = getPvals(deltaSNP, Gprime, outlierFilter), 
# #                negLog10Pval = -log10(pvalue),
# #                qvalue = p.adjust(p = pvalue, method = "BH")
# #                )
# #             
# #     return(SNPset)
# # }
