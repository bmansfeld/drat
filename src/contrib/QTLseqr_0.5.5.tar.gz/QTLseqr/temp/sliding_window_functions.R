countSNPs <- function(POS, windowSize = 1e6) {
    out <- numeric()
    left <- 1
    right <- 1
    for (i in 1:length(POS)) {
        while (right < length(POS) & POS[right + 1] <= POS[i] + windowSize / 2){
            right <- right + 1
    }
        while (POS[left] <= POS[i] - windowSize / 2) {
            left <- left + 1
            }
        out[i] <- right - left + 1 
    }   
    return(out)
} 

avgDeltaSNP <- function(POS, deltaSNP, windowSize = 1e6) {
    out <- numeric()
    left <- 1
    right <- 1
    for (i in 1:length(POS)) {
        while (right < length(POS) & POS[right + 1] <= POS[i] + windowSize / 2){
            right <- right + 1
        }
        while (POS[left] <= POS[i] - windowSize / 2) {
            left <- left + 1
        }
        out[i] <- mean(deltaSNP[left:right])
    }   
    return(out)
} 


avgDeltaSNP <- function(POS, deltaSNP, windowSize = 1e6) {
    out <- numeric()
    left <- 1
    right <- 1
    for (i in 1:length(POS)) {
        while (right < length(POS) & POS[right + 1] <= POS[i] + windowSize / 2){
            right <- right + 1
        }
        while (POS[left] <= POS[i] - windowSize / 2) {
            left <- left + 1
        }
        out[i] <- mean(deltaSNP[left:right])
    }   
    return(out)
} 

# 
# seq(from = 1, to = max(POS), stepSize)
