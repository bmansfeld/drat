library(ggplot2)
library(QTLseqr)

rawData <- system.file("extdata", "Yang_et_al_2013.table", package = "Yang2013data", mustWork = TRUE)

#wd <- "C:/Users/Ben/Google Drive/Documents/School/PhD/My Research/R packages/QTLseqr"
#setwd(wd)

HighBulk <- "SRR834931"
LowBulk <- "SRR834927"
#file <- "Yang_et_al_2013.table"
#file <-
#    "Yang_all_chroms.table"

Chroms <- paste0(rep("Chr", 12), 1:12)

df <-
    importFromGATK(
        file = rawData,
        highBulk = HighBulk,
        lowBulk = LowBulk,
        chromList = Chroms
     )

df_filt <-
    filterSNPs(
        df,
        refAlleleFreq = 0.20,
        minTotalDepth = 100,
        maxTotalDepth = 400,
        minSampleDepth = 40,
        minGQ = 99
    )


df_filt <- runGprimeAnalysis(df_filt,
    windowSize = 1e6,
    outlierFilter = "deltaSNP",
    filterThreshold = 0.2)

getFDRThreshold(df_filt, alpha = 0.05)

plotGprimeDist(df_filt, outlierFilter = "deltaSNP", filterThreshold = 0.2)
plotGprimeDist(df_filt, outlierFilter = "Hampel")

plotGprimeDist(SNPset = df_filt, outlierFilter = "Hampel") + ggplot2::theme(legend.position = "bottom") + guides(colour = guide_legend(nrow = 3))

p1 <- plotGprimeDist(SNPset = df_filt, outlierFilter = "Hampel") + 
    ggplot2::theme(legend.position = "bottom", legend.direction = "vertical") +
    guides(fill = guide_legend(nrow = ))
p2 <- plotGprimeDist(SNPset = df_filt, outlierFilter = "deltaSNP", filterThreshold = 0.1) + ggplot2::theme(legend.position = "bottom") 

ggarrange(p1, p2, labels = "auto")


p3 <- plotQTLStats(df_filt, var = "nSNPs", plotThreshold = TRUE, q = 0.01)
p4 <- plotQTLStats(df_filt, var = "Gprime", plotThreshold = TRUE, q = 0.01)
p5 <- plotQTLStats(df_filt, var = "deltaSNP", plotThreshold = TRUE, q = 0.01) + ggplot2::scale_y_reverse()

ggarrange(p3, p4, p5, labels = "auto", nrow = 3) 

getQTLTable(df_filt,alpha = 0.05)

p1 <- plotQTLStats(df_filt, var = "nSNPs", plotThreshold = TRUE, q = 0.01)
p2 <- plotQTLStats(df_filt, var = "Gprime", plotThreshold = TRUE, q = 0.01)
p3 <- plotQTLStats(df_filt, var = "negLog10Pval", plotThreshold = TRUE, q = 0.01)
p4 <- plotQTLStats(df_filt, var = "deltaSNP", plotThreshold = TRUE, q = 0.01)# + ggplot2::scale_y_reverse()


p1 <- plotQTLStats(df_filt, var = "nSNPs", plotThreshold = TRUE, q = 0.01, subset = "Chr8")
p2 <- plotQTLStats(df_filt, var = "Gprime", plotThreshold = TRUE, q = 0.01, subset = "Chr8")
p3 <- plotQTLStats(df_filt, var = "negLog10Pval", plotThreshold = TRUE, q = 0.01, subset = "Chr8")
p4 <- plotQTLStats(df_filt, var = "deltaSNP", plotThreshold = TRUE, q = 0.01, subset = "Chr8")# + ggplot2::scale_y_reverse()

library(ggpubr)
ggarrange(p1, p4, p2, p3, labels = "auto", align = "h")

tiff(filename = "Fig1-Chr8 Stats", width = )

sigReg <- GetSigRegions(df_filt, alpha = 0.001)




############# Using LocFit #############

Chr1 <- filter(df_filt, CHROM == "Chr1")
Chr2 <- filter(df_filt, CHROM == "Chr2")
Chr3 <- filter(df_filt, CHROM == "Chr3")

x <- Chr1$POS
y <- Chr1$GStat
data <- data.frame(cbind(x,y))
        


ggplot(df_filt, aes(x = POS,y = GStat)) + 
    stat_smooth(method="locfit", formula = y ~ lp(x, h = 6e6)) +
    facet_grid( ~ CHROM, scales = "free_x") 

df_filt_prime <- df_filt %>% 
    group_by(CHROM) %>% 
    mutate(Gprime = predict(locfit::locfit(GStat ~ locfit::lp(POS, h = 6e6, deg = 0)), POS))


df_filt_prime <- df_filt %>% 
    group_by(CHROM) %>% 
    mutate(GdeltaSNPprime = predict(locfit::locfit((GStat * deltaSNP) ~ locfit::lp(POS, h = 6e6, deg = 0)), POS))


df_filt_prime$pvals <- getPvals(df_filt_prime$Gprime)

ggplot(df_filt, aes(x = POS,y = -log10(pvals))) + 
    geom_line() + 
    geom_hline(yintercept = -log10(0.001659083)) + 
    facet_grid( ~ CHROM, scales = "free_x") 
    
model <- locfit(y ~ lp(x, h=1e6), data=data, kern="tcub")
xseq <- seq(0, max(x), length = max(x))
pred <- predict(model, newdata = data.frame(x = x))
data.locfit <- data.frame(x=xseq, y=pred)

ggplot(data,aes(x=x,y=y)) +
    geom_line(data=data.locfit,aes(x=x,y=y))
