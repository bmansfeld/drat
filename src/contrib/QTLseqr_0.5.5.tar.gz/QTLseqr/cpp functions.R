cppFunction('
  NumericVector rollmean_cpp( NumericVector x, NumericVector y,
    NumericVector xout, double width) {
    double total=0;
    unsigned int n=x.size(), nout=xout.size(), i, ledge=0, redge=0;
    NumericVector out(nout);

    for( i=0; i<nout; i++ ) {
    while( x[ redge ] - xout[i] <= width && redge<n )
    total += y[redge++];
    while( xout[i] - x[ ledge ] > width && ledge<n )
    total -= y[ledge++];
    if( ledge==redge ) { out[i]=NAN; total=0; continue; }
    out[i] = total / (redge-ledge);
    }
    return out;
    }')

cppFunction(
    '
    NumericVector countSNPs_cpp(NumericVector POS, double windowSize) {
    unsigned int nout=POS.size(), i, left=0, right=0;
    NumericVector out(nout);
    
    for( i=0; i < nout; i++ ) {
         while (right < nout & POS[right + 1] <= POS[i] + windowSize / 2)
              right++;
    
         while (POS[left] <= POS[i] - windowSize / 2)
              left++;
    
         out[i] = right - left + 1 ;
    }
    return out;
    }'
)



cppFunction(
    '
    NumericVector averageDeltaSNP_cpp(NumericVector POS, NumericVector deltaSNP, double windowSize) {
    unsigned int nout=POS.size(), i, left=0, right=0;
    double total = 0;
    NumericVector out(nout);
    
    for( i=0; i < nout; i++ ) {
         while (right < nout & POS[right + 1] <= POS[i] + windowSize / 2)
              total += deltaSNP[++right];
    
         while (POS[left] <= POS[i] - windowSize / 2)
              total -= deltaSNP[left++];

    if( left==right ) { out[i]=NAN; total=0; continue; }
         out[i] = total / (right - left + 1) ;
    }
    return out;
    }'
)

cppFunction(
    '
    NumericVector Gprime_cpp(NumericVector POS, NumericVector GStat, double windowSize) {
    unsigned int nout=POS.size(), i, j, left=0, right=0, n_in_window;
    double values_tmp[], distance_tmp[], stdDist[], ;
    NumericVector out(nout);
    
    for( i=0; i < nout; i++ ) {
    while (right < nout & POS[right + 1] <= POS[i] + windowSize / 2)
        right++;
    
    while (POS[left] <= POS[i] - windowSize / 2)
        left++;
    
    n_in_window = right - left + 1;
    double sum = 0;
    for (j = 0; j < n_in_window; j++){
        distance_tmp[j] = (POS[left + j] - POS[i]) / (windowSize / 2);
        numerator[j] = pow((1 - pow(distance_tmp[j], 3)), 3);
        sum =+ numerator[j];
    }
    for (j = 0; j < n_in_window; j++){
        values_tmp[j] = Gstat[left + j];
        
    }
    
    out[i] = tricube(values_tmp, distance_tmp);
    }
    return out;
    }'
)


cppFunction('
    double tricubeWeight(double values[], double distance[]){
    unsigned int i, n=values.size();
        for (i = 0; i < n; i++){
            
        }
    }
    ')

cppFunction('
  NumericVector rollmean_cpp( NumericVector x, NumericVector y,
    NumericVector xout, double width) {

    double total=0, oldtotal=0;
    unsigned int n=x.size(), nout=xout.size(), i, ledge=0, redge=0;
    NumericVector out(nout);


    for( i=0; i<nout; i++ ) {
    Rcout << "Finding window "<< i << " for x=" << xout[i] << "..." << std::endl;
    total = 0;

    // numbers to push into window
    while( x[ redge ] - xout[i] <= width && redge<n ) {
    Rcout << "Adding (x,y) = (" << x[redge] << "," << y[redge] << ")" ;
    Rcout << "; edges=[" << ledge << "," << redge << "]" << std::endl;
    total += y[redge++];
    }

    // numbers to pop off window
    while( xout[i] - x[ ledge ] > width && ledge<n ) {
    Rcout << "Removing (x,y) = (" << x[ledge] << "," << y[ledge] << ")";
    Rcout << "; edges=[" << ledge+1 << "," << redge-1 << "]" << std::endl;
    total -= y[ledge++];
    }
    if(ledge==n) Rcout << " OVER ";
    if( ledge==redge ) {
    Rcout<<" NO DATA IN INTERVAL " << std::endl << std::endl;
    oldtotal=total=0; out[i]=NAN; continue;}

    Rcout << "For interval [" << xout[i]-width << "," <<
    xout[i]+width << "], all points in interval [" << x[ledge] <<
    ", " << x[redge-1] << "]" << std::endl ;
    Rcout << std::endl;

    out[i] = ( oldtotal + total ) / (redge-ledge);
    oldtotal=total+oldtotal;
    }
    return out;
    }')



cppFunction('
  NumericVector rollmean_c2( NumericVector x, NumericVector y, double width,
    double Min, double Max) {

    double total = 0, redge,center;
    unsigned int n = (Max - Min) + 1,
    i, j=0, k, ledge=0, redgeIndex;
    NumericVector out(n);


    for (i = 0; i < n; i++){
    center = Min + i + 0.5;
    redge = center - width / 2;
    redgeIndex = 0;
    total = 0;

    while (x[redgeIndex] < redge){
    redgeIndex++;
    }
    j = redgeIndex;

    while (x[j] < redge + width){
    total += y[j++];

    }

    out[i] = total / (j - redgeIndex);
    }
    return out;

    }')

# Set up example data
x = seq(0,4*pi,length.out=2500)
y = sin(x) + rnorm(length(x),0.5,0.5)
plot(x,y,pch=20,col="black",
    main="Sliding window mean; width=1000000",
    sub="rollmean_c in red      rollmean_r overlaid in white.")


c.out = rollmean_c2(x,y,width=1000000,Min = min(x), Max = max(x))
lines(min(x):max(x),c.out,col="red",lwd=3)



