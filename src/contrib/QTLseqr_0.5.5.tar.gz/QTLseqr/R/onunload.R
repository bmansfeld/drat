.onUnload <- function (libpath) {
    library.dynam.unload("QTLseqr", libpath)
}