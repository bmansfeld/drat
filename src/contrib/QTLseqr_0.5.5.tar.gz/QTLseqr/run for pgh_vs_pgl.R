HighBulk <- "PGH"
LowBulk <- "PGL"

Chromosomes <- paste0(rep("Chr", 7), 1:7)

file<-"../../Bioinformatics/QTLseq/VCF quality control/PvsG_filtered_snps.table"

df <-
    ImportFromGATK(
        filename = file,
        HighBulk = HighBulk,
        LowBulk = LowBulk,
        ChromList = Chromosomes,
        method = "one"
    )

df_filt <-
    FilterSNPs(
        df,
        RefAlleleFreq = 0.3,
        MinTotalDepth = 40,
        MaxTotalDepth = 80,
        MinSampleDepth = 20,
        MinGQ = 99,
        Verbose = T
    )

df_filt_4Mb <- runGprimeAnalysis(SNPset = df_filt, windowSize = 4e6, outlierFilter = "deltaSNP")

plotGprimeDist(df_filt_6Mb)

p1 <- plotQTLstats(df_filt_6Mb, var = "nSNPs", plotThreshold = TRUE, q = 0.01)
p2 <- plotQTLstats(df_filt_6Mb, var = "Gprime", plotThreshold = TRUE, q = 0.01)
p3 <- plotQTLstats(df_filt_6Mb, var = "negLogPval", plotThreshold = TRUE, q = 0.01)
p4 <- plotQTLstats(df_filt_6Mb, var = "deltaSNP", plotThreshold = TRUE, q = 0.01)

sigReg <- GetSigRegions(df_filt_6Mb, alpha = 0.001)

source("../../Bioinformatics/RNAseq analysis/multiplot.R")
multiplot(p1, p2, p3, p4, cols = 1)


#
# tmp <- df_filt_6Mb[order(df_filt_6Mb$pval, decreasing = F), ]
# q <- 0.05
# tmp$thresholds <- q * ((1:length(tmp$pval)) / length(tmp$pval))
#
# fdrT <- tmp[sum(tmp$qval <= 0.05), "pval"]
#
# ggplot(data = df_filt_6Mb) +
#     geom_line(aes(x = POS, y = -log10(pval))) +
#     geom_hline(yintercept = -log10(fdrT), color = "red") +
#     facet_grid( ~ CHROM, scales = "free_x") +
#     #scale_x_continuous(labels = format_genomic(), name = "Genomic Position") +
#     theme_bw()
#
# ggplot(data = df_filt_6Mb) +
#     geom_line(aes(x = POS, y = Gprime)) +
#     #geom_hline(yintercept = -log10(fdrT), color = "red") +
#     facet_grid( ~ CHROM, scales = "free_x") +
#     #scale_x_continuous(labels = format_genomic(), name = "Genomic Position") +
#     theme_bw()
#
#
# Chr3_1 <- subset(df_filt_1Mb, CHROM == "Chr3")
# Chr3_6 <- subset(df_filt_6Mb, CHROM == "Chr3")
# Chr3_4.5 <- subset(df_filt_4.5Mb, CHROM == "Chr3")
#
#
# ggplot(data = Chr3) +
#     geom_point(aes(x = POS, y = -log10(pval))) +
#     geom_hline(yintercept = -log10(fdrT), color = "red") +
#     facet_grid(~CHROM, scales = "free_x") +
#     scale_x_continuous(labels=format_genomic(),name = "Genomic Position") +
#     theme_bw()
#
# min(Chr3[Chr3$pval < fdrT, "POS"])
# max(Chr3[Chr3$pval < fdrT, "POS"])
#
# ggplot(data = Chr3s) +
#     geom_line(aes(x = POS, y = Gprime)) +
#     facet_grid(~Win, scales = "free_x") +
#     scale_x_continuous(labels=format_genomic(),name = "Genomic Position") +
#     theme_bw()

